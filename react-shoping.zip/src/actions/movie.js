export const setMovies = movies => ({

    type: 'SET_MOVIES',
  
    payload: movies
  
  });